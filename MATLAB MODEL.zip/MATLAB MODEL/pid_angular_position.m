
function [E1, E2, E3] = pid_angular_position(q1, q2, q3, q4)
    % Parámetros del satélite
    I = diag([120, 100, 80]); % Momento de inercia (ejemplo)
    Kp_outer = 0.001; % Ganancia proporcional del lazo externo
    Ki_outer = 0.001; % Ganancia integral del lazo externo
    Kd_outer = 0.1;   % Ganancia derivativa del lazo externo

    Kp_inner = 0.01; % Ganancia proporcional del lazo interno
    Ki_inner = 0.01; % Ganancia integral del lazo interno
    Kd_inner = 0.1;  % Ganancia derivativa del lazo interno

    % Estado inicial
    actual_quaternion = [q1, q2, q3, q4];
    w = [0; 0; 0]; % Velocidad angular inicial (asumida cero)

    % Estado deseado
    desired_quaternion = [1, 0, 0, 0]; % Quaternion de actitud deseado (apuntar al nadir)

    % Inicializar términos integrales
    integral_error_outer = [0; 0; 0];
    integral_error_inner = [0; 0; 0];

    % Tiempo de muestreo
    dt = 0.01; % Paso de tiempo (ajustable)
    
    % Error de actitud
    q_err = quatmultiply(quatconj(desired_quaternion), actual_quaternion);

    % Controlador de lazo externo (PID)
    [desired_angular_velocity, integral_error_outer] = outer_loop_controller_PID(q_err, Kp_outer, Ki_outer, Kd_outer, integral_error_outer, dt);

    % Error de velocidad angular
    angular_velocity_error = desired_angular_velocity - w;

    % Controlador de lazo interno (PID)
    [body_moments, integral_error_inner] = inner_loop_controller_PID(angular_velocity_error, Kp_inner, Ki_inner, Kd_inner, integral_error_inner, dt);

    % Dinámica de la nave espacial
    w_dot = I \ (body_moments - cross(w, I * w));
    w = w + w_dot * dt;

    % Actualizar el quaternion
    q_dot = 0.5 * quatmultiply([0, w'], actual_quaternion);
    actual_quaternion = actual_quaternion + q_dot * dt;
    actual_quaternion = actual_quaternion / norm(actual_quaternion); % Normalizar

    % Convertir el quaternion actual a ángulos de Euler
    euler_angles = quat2eul(actual_quaternion, 'ZYX'); % El quaternion debe ser un vector fila

    % Convertir la posición angular a grados
    angular_position = rad2deg(euler_angles);
    E1 = angular_position(1);
    E2 = angular_position(2);
    E3 = angular_position(3);
end

% Función del controlador de lazo externo (PID)
function [desired_angular_velocity, integral_error] = outer_loop_controller_PID(q_err, Kp, Ki, Kd, integral_error, dt)
    angle_error_by_2 = acos(q_err(1));
    sin_angle_error_by_2 = sin(angle_error_by_2);

    if sin_angle_error_by_2 < eps
        sin_angle_error_by_2 = eps; % Para evitar división por cero
    end

    angular_velocity_error = q_err(2:4)' / sin_angle_error_by_2;

    integral_error = integral_error + angular_velocity_error * dt;
    derivative_error = angular_velocity_error / dt;
    desired_angular_velocity = Kp * angular_velocity_error + Ki * integral_error + Kd * derivative_error;
end

% Función del controlador de lazo interno (PID)
function [body_moments, integral_error] = inner_loop_controller_PID(angular_velocity_error, Kp, Ki, Kd, integral_error, dt)
    integral_error = integral_error + angular_velocity_error * dt;
    derivative_error = angular_velocity_error / dt;

    body_moments = Kp * angular_velocity_error + Ki * integral_error + Kd * derivative_error;
end

% Funciones auxiliares
function q_out = quatmultiply(q, r)
    q_out = [q(1)*r(1) - q(2)*r(2) - q(3)*r(3) - q(4)*r(4), ...
             q(1)*r(2) + q(2)*r(1) + q(3)*r(4) - q(4)*r(3), ...
             q(1)*r(3) - q(2)*r(4) + q(3)*r(1) + q(4)*r(2), ...
             q(1)*r(4) + q(2)*r(3) - q(3)*r(2) + q(4)*r(1)];
end

function q_conj = quatconj(q)
    q_conj = [q(1), -q(2), -q(3), -q(4)];
end
